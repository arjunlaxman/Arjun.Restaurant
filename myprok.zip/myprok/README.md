# Project Name
Arjun's Restaurant

# restaurant
A basic website for a restaurant

# Open index.html to access the website
