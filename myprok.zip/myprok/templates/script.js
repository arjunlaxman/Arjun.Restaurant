
window.addEventListener('DOMContentLoaded', (event) => {
    
    const reservationForm = document.getElementById('reservation-form');
    reservationForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        

        if (nameInput.value.trim() === '') {
            // Display error message for name field
            
        } else if (emailInput.value.trim() === '') {
            // Display error message for email field
        } else {
            // Submit the form if all fields are valid
            reservationForm.submit();
        }
    });

    
    const contactForm = document.getElementById('contact-form');
    contactForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
       

        if (nameInput.value.trim() === '') {
            // Display error message for name field
        } else if (emailInput.value.trim() === '') {
            // Display error message for email field
        } else {
            // Submit the form if all fields are valid
            contactForm.submit();
        }
    });
});
